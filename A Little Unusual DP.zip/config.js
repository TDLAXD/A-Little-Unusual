/// <reference types="node"/>
// ---------------------------------------------------------------------
// This template script adds a few useful arguments to the mcbuild cli:
// -clean: Errases the data folder before building.
// ---------------------------------------------------------------------
const fs = require('fs')
const { exec } = require('child_process')

module.exports = {
	global: {
		preBuild: build => {
			if (process.argv.includes('-clean')) {
				try {
					fs.rmSync('./data/', { recursive: true })
				} catch (e) {}
				fs.mkdirSync('./data/')
			}
		},
		postBuild: build => {},
	},
	mc: {
		dev: true,
		header: '# built using mc-build (https://github.com/mc-build/mc-build)',
		internalScoreboard: 'i',
		generatedDirectory: 'zzz',
		rootNamespace: null,
	},
}
